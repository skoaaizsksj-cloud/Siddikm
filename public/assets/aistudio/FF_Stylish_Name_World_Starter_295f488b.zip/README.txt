FF Stylish Name World — starter kit

Files:
- index.html: responsive name generator + Supabase-powered admin panel
- supabase_setup.sql: database tables, security policies, sample styles

Setup on Android:
1. Create a free Supabase project at https://supabase.com/.
2. Open SQL Editor and run supabase_setup.sql.
3. In Authentication > Users, create your admin user with email/password.
4. Copy that user's UUID. In SQL Editor run:
   insert into public.admin_users (user_id) values ('PASTE-USER-UUID-HERE');
5. Open Project Settings > API. Copy Project URL and anon/public key.
6. Open index.html in a text editor. Replace YOUR_SUPABASE_PROJECT_URL and YOUR_SUPABASE_ANON_KEY.
   Never put a service_role key in index.html.
7. Publish index.html using a static host such as GitHub Pages or Netlify. The browser needs internet access to load Supabase JS.
8. Visit the site, log in with the admin email/password, and add styles.

Important:
- This is a starter template, not yet deployed to a public URL.
- Keep the admin account password private and enable email confirmation if available.
- Database security relies on Supabase Row Level Security policies in the SQL file.
- Add extra validation/rate limiting before heavy public traffic.
- Free Fire may reject some Unicode symbols or long names; test in-game.
